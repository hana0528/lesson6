# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '55090336863d54e62aa0d1ca6a8b67c28b35ecef4def423c6354ce7c536eb1f388a22382795c6718573da3ecd3e40db166be600d9145e9c046831b78d6a7565e'